import cv2
import numpy as np



img1 = cv2.imread('/home/pengshanzhen/try/1_1_1.jpg')
img2 = cv2.imread('/home/pengshanzhen/try/1_1_2.jpg')
img3 = cv2.imread('/home/pengshanzhen/try/1_2_1.jpg')
img4 = cv2.imread('/home/pengshanzhen/try/1_2_2.jpg')

gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
gray3 = cv2.cvtColor(img3, cv2.COLOR_BGR2GRAY)
gray4 = cv2.cvtColor(img4, cv2.COLOR_BGR2GRAY)


image1 = np.concatenate([gray1, gray3],axis=1)
image2 = np.concatenate([gray2, gray4],axis=1)

image = np.concatenate((image1, image2))


cv2.imwrite('/home/pengshanzhen/try/1/copy.jpg',image)
