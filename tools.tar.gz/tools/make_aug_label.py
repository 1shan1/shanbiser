import os
import random


f = open('/home/pengshanzhen/high-quality-densitymap/bishe/branch_classification/training-augment/train.txt','r')
train_file =open('/home/pengshanzhen/high-quality-densitymap/bishe/branch_classification/training-augment/train_aug.txt','w')
#test_file = open('/home/pengshanzhen/crowdcount-mcnn/data/formatted_trainval/shanghaitech_part_A_patches_9/training-augment/data/L_test.txt','w')
data_path ='/home/pengshanzhen/high-quality-densitymap/bishe/branch_classification/training-augment/train_augment/'
file_str_list = []
for line in f.readlines():
  label_index = line.rfind(' ')
  label_str = line[label_index+1:label_index+2]
  fname = line.split('/')[8]
  data_index = fname.rfind('.')
  data_name = fname[:data_index]
   
  #print(data_name)
  #exit()
  #data_index = line.rfind('.')
  #pic_path = line[:data_index]
  
  #dst_str_0 = pic_path +'X_agmt'+'_'+'0'+'.jpg'+' '+label_str+'\n'
  #file_str_list.append(dst_str_0)pythpon
  #dst_str_1 = pic_path +'X_agmt'+'_'+'1'+'.jpg'+' '+label_str+'\n'
  #file_str_list.append(dst_str_1)
  #dst_str_2 = pic_path +'X_agmt'+'_'+'2'+'.jpg'+' '+label_str+'\n'
  #file_str_list.append(dst_str_2)
  
  for i in range(3):
    
    dst_str = data_path + data_name + 'X_agmt'+'_'+str(i)+'.jpg'+' '+label_str+'\n'
    file_str_list.append(dst_str)


random.shuffle(file_str_list)

for txt_str in file_str_list:
    train_file.write(txt_str)

