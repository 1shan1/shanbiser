import os
import random




file_str_list = []


pro_file = open('/data_2/yolo_testcar/baoding/baoding_plate_list.txt','w')
data_path = '/data_2/yolo_testcar/baoding/baoding_plate'

filelist = os.listdir(data_path)

for fname in filelist:
  img_path =os.path.join(data_path,fname)
  img_filelist = os.listdir(img_path)
  if len(img_filelist) == 0:
      continue
  for img_fname in img_filelist:
    every_img_path = os.path.join(img_path,img_fname)
    
    dst_str = every_img_path +'\n'
    file_str_list.append(dst_str) 


for txt_str in file_str_list:
  
   pro_file.write(txt_str)

