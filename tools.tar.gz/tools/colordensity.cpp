 #include <caffe/caffe.hpp>
 #include <opencv2/opencv.hpp>
 #include <glog/logging.h>
 #include <fstream>
 #include <cmath>
 #include <string>
 #include <vector>


using namespace cv;
using namespace std;
class renliu
{
public:
    renliu()
    {
        netname_="./crowd_deploy.prototxt";
        modelname_="/hard_disk2/Receive_files/wxc/Image_Crowd_Counting/me-caffe/test/crowd_iter_f_41000.caffemodel";

        caffe::Caffe::set_mode(caffe::Caffe::GPU);
        caffe::Caffe::SetDevice(0);


        net_.reset(new caffe::Net<float>(netname_, caffe::TEST));
        net_->CopyTrainedLayersFrom(modelname_);
    }

    void process(const cv::Mat &imgin, cv::Mat &result, float &sum_people)
    {
        double start, end;
        start=cv::getTickCount();
        
        
        cv::Mat x=imgin.clone();
        cv::resize(imgin, x, cv::Size(imgin.cols/4*4, imgin.rows/4*4));
            
        auto &input_layer=net_->input_blobs()[0];
        input_layer->Reshape({1, 1,
                x.rows, x.cols});
        net_->Reshape();
          

        float *input_data = input_layer->mutable_cpu_data();

        std::vector<cv::Mat>  input_channels;
        for (int j=0; j<input_layer->shape()[1]; j++)
        {
            cv::Mat channel(input_layer->height(), input_layer->width(), CV_32FC1, input_data);
            input_channels.push_back(channel);
            input_data += input_layer->width()*input_layer->height();
        }
        
        
        
        
        if (x.channels()==3)
            cv::cvtColor(x, x, cv::COLOR_BGR2GRAY);
        
        cv::Mat floatImg;
        x.convertTo(floatImg, CV_32FC1);
        floatImg = floatImg/127.5-1;


        cv::split(floatImg, input_channels);

        net_->Forward();
        
        caffe::shared_ptr<caffe::Blob<float> > res=net_->blob_by_name("fuse_conv");
        const float *data=res->cpu_data();
        result=cv::Mat(res->shape(2), res->shape(3), CV_8UC1);
        //result=cv::Mat(cv::Size(res->shape(3),res->shape(2)), CV_32FC1,(float*)data);
        
        float maxs=std::numeric_limits<float>::lowest();
        //LOG(INFO) << "maxs " << maxs;
        maxs = 0.0;
        float sums=0.;
        //LOG(INFO)<<result.rows<<"  "<<result.cols<<" "<<data[0]<<" "<<data[100];
        for (int i=0; i<result.rows*result.cols; i++)
        {
           //LOG(INFO) << "abs data[i] " << fabs(data[i]);
           //LOG(INFO) << "abs maxs " << fabs(maxs);
            if (fabs(maxs)<fabs(data[i]))
            {
                maxs=data[i];
                //LOG(INFO) << "maxs " << maxs;
                }
            sums+=data[i];
        }
        LOG(INFO) << "res " << sums;
        sum_people = sums;
        unsigned char *dst=result.data;
        //LOG(INFO) << "maxs " << maxs;
        for (int i=0; i<result.rows*result.cols; i++)
        {
            dst[i]=fabs(data[i])*255/fabs(maxs);
            //LOG(INFO) << "dst[i] " << dst[i];
        }
        
        end=cv::getTickCount();
        LOG(INFO) << modelname_ << " single img cal time: [ " << (end-start)*1000/cv::getTickFrequency() << "ms ]";
        LOG(INFO) << std::endl;
    }
private:
    std::string netname_;
    std::string modelname_;

    caffe::shared_ptr< caffe::Net<float> > net_;
};
 
void falColor(cv::Mat src,cv::Mat &dst)
{
    src.convertTo(src,CV_8UC1);
    dst=cv::Mat(src.rows,src.cols,CV_8UC3,cv::Scalar::all(0));
    int L=255;
    for(int i=0;i<dst.rows;i++)
    {
        for(int j=0;j<dst.cols;j++)
        {
            int temp=src.at<uchar>(i,j);
            if(temp<L/4)
            {
                dst.at<cv::Vec3b>(i,j)[2]=0;
                dst.at<cv::Vec3b>(i,j)[1]=4*temp;
                dst.at<cv::Vec3b>(i,j)[0]=L;
            }
            else if(temp<=L/2)
            {
                dst.at<cv::Vec3b>(i,j)[2]=0;
                dst.at<cv::Vec3b>(i,j)[1]=L;
                dst.at<cv::Vec3b>(i,j)[0]=2*L-4*temp;
            }
            else if(temp<=3*L/4)
            {
                dst.at<cv::Vec3b>(i,j)[2]=4*temp-2*L;
                dst.at<cv::Vec3b>(i,j)[1]=L;
                dst.at<cv::Vec3b>(i,j)[0]=0;
            }
            else
            {
                dst.at<cv::Vec3b>(i,j)[2]=L;
                dst.at<cv::Vec3b>(i,j)[1]=4*L-4*temp;
                dst.at<cv::Vec3b>(i,j)[0]=0;
            }
        }
    }


}
void split_img(cv::Mat &src, vector<Mat> &dst)
{
    const int height = src.rows;
    const int width = src.cols;
    int hf_height = height / 2;
    int hf_width = width / 2;
    Rect rect1(0, 0, hf_width, hf_height);
    cv::Mat tmp1(src, rect1);
    dst.push_back(tmp1);
    Rect rect2(hf_width, 0, hf_width, hf_height);
    cv::Mat tmp2(src, rect2);
    dst.push_back(tmp2);
    Rect rect3(0, hf_height, hf_width, hf_height);
    cv::Mat tmp3(src, rect3);
    dst.push_back(tmp3);
    Rect rect4(hf_width, hf_height, hf_width, hf_height);
    cv::Mat tmp4(src, rect4);
    dst.push_back(tmp4);
    
}
int main(int argc, char *argv[])
{
    renliu m;
    
    std::ifstream fid(argv[1]);
    std::string line;
    while(getline(fid, line))
    {
        cv::Mat img=cv::imread(line);
        vector<Mat> src_split;
        split_img(img, src_split);
        for(int i = 0; i < 4; i++)
        {
            cv::Mat res, dst;
            float sums; 
            m.process(src_split[i], res, sums);
            std::string str_sums = std::to_string(sums);
            cv::resize(res, res, cv::Size(), 4., 4.);
            falColor(res, dst);
            cv::imshow("mx1", dst);
            int font_face = cv::FONT_HERSHEY_COMPLEX;   
            double font_scale = 2;  
            int thickness = 2;  
            cv::Point origin(20, 50);
            cv::putText(src_split[i], str_sums, origin, font_face, font_scale, cv::Scalar(0, 255, 255), thickness, 8, 0);  
            cv::imshow("mx", src_split[i]);
            waitKey(0);
        }
        // cv::resize(img, img, cv::Size(), 0.4, 0.4);
        // cv::Mat res, dst;
        // float sums; 
        // m.process(img, res, sums);
        // std::string str_sums = std::to_string(sums);
        // LOG(INFO) << "str_sums " << str_sums;
        // cv::resize(res, res, cv::Size(), 4., 4.);
        // falColor(res, dst);
        // cv::imshow("mx1", dst);
        // int font_face = cv::FONT_HERSHEY_COMPLEX;   
		// 		double font_scale = 2;  
		// 		int thickness = 2;  
		// 		cv::Point origin(100, 100);
		// 		cv::putText(img, str_sums, origin, font_face, font_scale, cv::Scalar(0, 255, 255), thickness, 8, 0);  
		// 		cv::imshow("mx", img);
        // cv::waitKey(0);
    }
    
    
    return 0;
}
















