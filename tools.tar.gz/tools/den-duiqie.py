import cv2  
import numpy  
import math  
import string  
import os  
import pandas as pd
import numpy as np
import random



den_list = []
train_file = open('/data_1/data/formatted_trainval/den_to_count.txt','w')
#path = '/data_1/data/formatted_trainval/shanghaitech_part_A_patches_2/train/'
den_path = '/data_1/data/formatted_trainval/shanghaitech_part_A_patches_2/train_den'
dstPath ='/data_1/data/formatted_trainval/split_2/'
filelist = os.listdir(den_path)
for fname in filelist:
  every_img_path = os.path.join(den_path,fname)
  #img = cv2.imread(every_img_path)
  den = pd.read_csv(every_img_path, sep=',',header=None).as_matrix() 
  den = den.astype(np.float32, copy=False)
  img_fname = every_img_path.split('/')[6]
  img_qian = img_fname.split('.')[0]
  
  
  








  n = 2


  h = den.shape[0]  
  w = den.shape[1]  

      

      

  for i in range(n):  
      for j in range(n):  
          x = (w/2) * i  
          y = (h/2) * j  
              
        
              
          patch = den[y:y+(h/2), x:x+(w/2)]
          gt_count = np.sum(patch)
          dst_str = dstPath+img_qian+'_%d' %(i+1)+'_%d' %(j+1)+'.jpg'+' '+str(gt_count)+'\n'
          den_list.append(dst_str) 
          #cv2.imwrite(dstPath+img_qian+'_%d' %(i+1)+'_%d' %(j+1)+'.txt', patch);  

for txt_str in den_list:
    train_file.write(txt_str)

       
        
