import cv2  
import numpy  
import math  
import string  
import os  




path = '/data_1/data/formatted_trainval/shanghaitech_part_A_patches_2/val/'
dstPath ='/data_1/data/formatted_trainval/val_split_2/'
filelist = os.listdir(path)
for fname in filelist:
  every_img_path = os.path.join(path,fname)
  img = cv2.imread(every_img_path)
  img_fname = every_img_path.split('/')[6]
  img_qian = img_fname.split('.')[0]
  
  
  








  n = 2


  h = img.shape[0]  
  w = img.shape[1]  

      

      
    
  for i in range(n):  
      for j in range(n):  
          x = (w/2) * i  
          y = (h/2) * j  
              
        
              
          patch = img[y:y+(h/2), x:x+(w/2), :]  
          cv2.imwrite(dstPath+img_qian+'_%d' %(i+1)+'_%d' %(j+1)+'.jpg', patch);  
         
        
