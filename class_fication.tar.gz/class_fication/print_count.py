import cv2
import numpy as np
import os
import pandas as pd
import random


file_str_list = []
train_file = open('/data_1/data/formatted_trainval/val_den_with_label.txt','w')
f = open('/data_1/data/formatted_trainval/val_den_with_count.txt','r')
den_lines = f.readlines()
i = 0
for line in den_lines:
  label_index = line.rfind(' ')
  pic_path = line[:label_index]
  label = line[label_index+1:]
  label_count = float(label)
  
  label_str = '0'
  if label_count <= 5:
    label_str ='0'
  elif label_count <= 10:
    label_str ='1'
  elif label_count <= 20:
    label_str ='2'
  elif label_count <= 40:
    label_str ='3'
  else:
    
    label_str = '4'
  dst_str = pic_path +' '+label_str+'\n'
  file_str_list.append(dst_str)


random.shuffle(file_str_list)

for txt_str in file_str_list:
    train_file.write(txt_str)
